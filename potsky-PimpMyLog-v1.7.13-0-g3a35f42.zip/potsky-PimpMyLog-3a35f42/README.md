Pimp my Log 
===========

[![Latest Stable Version](https://poser.pugx.org/potsky/pimp-my-log/v/stable.svg)](https://packagist.org/packages/potsky/pimp-my-log) [![Build Status](https://travis-ci.org/potsky/PimpMyLog.svg)](https://travis-ci.org/potsky/PimpMyLog)

All informations are available on [pimpmylog.com](http://pimpmylog.com).

Please **do not open issues on GitHub**, this is for dev only.  
Support, FAQ, knowledge base, ... are on [support.pimpmylog.com](http://support.pimpmylog.com).

Please star this repository to support *Pimp My Log* !

